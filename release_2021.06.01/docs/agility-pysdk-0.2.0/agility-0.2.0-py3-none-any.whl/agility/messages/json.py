import sys
from typing import Optional, List, Any
from .messages import *


# Enum definitions

class EndEffector:
    LEFT_FOOT='left-foot'
    LEFT_HAND='left-hand'
    RIGHT_FOOT='right-foot'
    RIGHT_HAND='right-hand'

class RobotFrame:
    """Not a comprehensive list, additional sensor names are also allowed."""
    BASE='base'
    LEFT_HAND='left-hand'
    RIGHT_HAND='right-hand'
    LEFT_FOOT='left-foot'
    RIGHT_FOOT='right-foot'
    CENTER_OF_MASS='center-of-mass'
    MEAN_HAND='mean-hand'
    MEAN_FOOT='mean-foot'
    IMU='imu'
    GPS='gps'

class ObjectAttribute:
    NAME='name'
    PARENT='parent'
    CHILDREN='children'
    POSE='pose'
    VELOCITY='velocity'
    TIMEOUT='timeout'
    MASS='mass'
    POLYGON='polygon'
    APRIL_TAG_ID='april-tag-id'
    KEEP_OUT='keep-out'
    STEPPABLE='steppable'
    BOX_GEOMETRY='box-geometry'
    PICKABLE='pickable'

class Privilege:
    CHANGE_ACTION_COMMAND='change-action-command'

class ObjectPriorityOrder:
    OLDEST='oldest'
    NEWEST='newest'
    LEAST_RECENTLY_UPDATED='least-recently-updated'
    MOST_RECENTLY_UPDATED='most-recently-updated'

class OperationMode:
    DISABLED='disabled'
    DAMPING='damping'
    LOCOMOTION='locomotion'
    JOINT='joint'
    LOW_LEVEL_API='low-level-api'

class LocomotionType:
    GROUNDED_RUN='grounded-run'
    WALK='walk'
    RUN='run'

class StartMode:
    AUTO='auto'
    ASSISTED='assisted'
    ROPE='rope'
    DEPLOYMENT='deployment'
    PUSH_UP='push-up'

class ActionStatus:
    RUNNING='running'
    SUCCESS='success'
    FAILURE='failure'
    INACTIVE='inactive'

class ReplaceActionFallback:
    ERROR='error'
    SEQUENTIAL='sequential'
    CONCURRENT='concurrent'

class DisturbanceFrame:
    WORLD='world'
    BODY='body'
    COM='com'
    COM_WORLD='com-world'

class SimulationMode:
    KINEMATIC='kinematic'
    DYNAMIC='dynamic'



# Struct definitions

class Pose(Struct):
    rpy: List[float]
    a: float
    xyz: List[float]
    xy: List[float]
    rpyxyz: List[float]
    rpyxy: List[float]
    axyz: List[float]
    axy: List[float]
    rpyd: List[float]
    rpyxyzd: List[float]
    rpyxyd: List[float]
    axyzd: List[float]
    axyd: List[float]
    ad: float
    q: List[float]
    qxyz: List[float]
    qxy: List[float]
    m34: List[float]
    def __init__(
            self,
            rpy: List[float] = None,
            a: float = None,
            xyz: List[float] = None,
            xy: List[float] = None,
            rpyxyz: List[float] = None,
            rpyxy: List[float] = None,
            axyz: List[float] = None,
            axy: List[float] = None,
            rpyd: List[float] = None,
            rpyxyzd: List[float] = None,
            rpyxyd: List[float] = None,
            axyzd: List[float] = None,
            axyd: List[float] = None,
            ad: float = None,
            q: List[float] = None,
            qxyz: List[float] = None,
            qxy: List[float] = None,
            m34: List[float] = None,
    ):
        super().__init__(
            rpy=rpy,
            a=a,
            xyz=xyz,
            xy=xy,
            rpyxyz=rpyxyz,
            rpyxy=rpyxy,
            axyz=axyz,
            axy=axy,
            rpyd=rpyd,
            rpyxyzd=rpyxyzd,
            rpyxyd=rpyxyd,
            axyzd=axyzd,
            axyd=axyd,
            ad=ad,
            q=q,
            qxyz=qxyz,
            qxy=qxy,
            m34=m34,
        )

class GpsPose(Struct):
    rpy: List[float]
    a: float
    xyz: List[float]
    xy: List[float]
    rpyxyz: List[float]
    rpyxy: List[float]
    axyz: List[float]
    axy: List[float]
    rpyd: List[float]
    rpyxyzd: List[float]
    rpyxyd: List[float]
    axyzd: List[float]
    axyd: List[float]
    ad: float
    q: List[float]
    qxyz: List[float]
    qxy: List[float]
    m34: List[float]
    h: float
    ll: List[float]
    hll: List[float]
    def __init__(
            self,
            rpy: List[float] = None,
            a: float = None,
            xyz: List[float] = None,
            xy: List[float] = None,
            rpyxyz: List[float] = None,
            rpyxy: List[float] = None,
            axyz: List[float] = None,
            axy: List[float] = None,
            rpyd: List[float] = None,
            rpyxyzd: List[float] = None,
            rpyxyd: List[float] = None,
            axyzd: List[float] = None,
            axyd: List[float] = None,
            ad: float = None,
            q: List[float] = None,
            qxyz: List[float] = None,
            qxy: List[float] = None,
            m34: List[float] = None,
            h: float = None,
            ll: List[float] = None,
            hll: List[float] = None,
    ):
        super().__init__(
            rpy=rpy,
            a=a,
            xyz=xyz,
            xy=xy,
            rpyxyz=rpyxyz,
            rpyxy=rpyxy,
            axyz=axyz,
            axy=axy,
            rpyd=rpyd,
            rpyxyzd=rpyxyzd,
            rpyxyd=rpyxyd,
            axyzd=axyzd,
            axyd=axyd,
            ad=ad,
            q=q,
            qxyz=qxyz,
            qxy=qxy,
            m34=m34,
            h=h,
            ll=ll,
            hll=hll,
        )

class SpatialVector(Struct):
    rpy: List[float]
    a: float
    xyz: List[float]
    xy: List[float]
    rpyxyz: List[float]
    rpyxy: List[float]
    axyz: List[float]
    axy: List[float]
    rpyd: List[float]
    rpyxyzd: List[float]
    rpyxyd: List[float]
    axyzd: List[float]
    axyd: List[float]
    ad: float
    def __init__(
            self,
            rpy: List[float] = None,
            a: float = None,
            xyz: List[float] = None,
            xy: List[float] = None,
            rpyxyz: List[float] = None,
            rpyxy: List[float] = None,
            axyz: List[float] = None,
            axy: List[float] = None,
            rpyd: List[float] = None,
            rpyxyzd: List[float] = None,
            rpyxyd: List[float] = None,
            axyzd: List[float] = None,
            axyd: List[float] = None,
            ad: float = None,
    ):
        super().__init__(
            rpy=rpy,
            a=a,
            xyz=xyz,
            xy=xy,
            rpyxyz=rpyxyz,
            rpyxy=rpyxy,
            axyz=axyz,
            axy=axy,
            rpyd=rpyd,
            rpyxyzd=rpyxyzd,
            rpyxyd=rpyxyd,
            axyzd=axyzd,
            axyd=axyd,
            ad=ad,
        )

class ObjectSelector(Struct):
    object_id: Optional[int]
    has_attributes: Optional[List[str]]
    name: Optional[str]
    owned: Optional[bool]
    user_object: Optional[bool]
    april_tag_id: Optional[int]
    descendant_of: Optional['ObjectSelector']
    ancestor_of: Optional['ObjectSelector']
    include: List['ObjectSelector']
    exclude: List['ObjectSelector']
    special_frame: Optional[str]
    robot_frame: Optional[str]
    command_frame: Optional[str]
    owned_object_name: Optional[str]
    user_object_name: Optional[str]
    map_name: Optional[str]
    terrain_map_name: Optional[str]
    snapshot_camera_name: Optional[str]
    priority_order: str
    def __init__(
            self,
            object_id: Optional[int] = None,
            has_attributes: Optional[List[str]] = None,
            name: Optional[str] = None,
            owned: Optional[bool] = None,
            user_object: Optional[bool] = None,
            april_tag_id: Optional[int] = None,
            descendant_of: Optional['ObjectSelector'] = None,
            ancestor_of: Optional['ObjectSelector'] = None,
            include: List['ObjectSelector'] = None,
            exclude: List['ObjectSelector'] = None,
            special_frame: Optional[str] = None,
            robot_frame: Optional[str] = None,
            command_frame: Optional[str] = None,
            owned_object_name: Optional[str] = None,
            user_object_name: Optional[str] = None,
            map_name: Optional[str] = None,
            terrain_map_name: Optional[str] = None,
            snapshot_camera_name: Optional[str] = None,
            priority_order: str = None,
    ):
        super().__init__(
            object_id=object_id,
            has_attributes=has_attributes,
            name=name,
            owned=owned,
            user_object=user_object,
            april_tag_id=april_tag_id,
            descendant_of=descendant_of,
            ancestor_of=ancestor_of,
            include=include,
            exclude=exclude,
            special_frame=special_frame,
            robot_frame=robot_frame,
            command_frame=command_frame,
            owned_object_name=owned_object_name,
            user_object_name=user_object_name,
            map_name=map_name,
            terrain_map_name=terrain_map_name,
            snapshot_camera_name=snapshot_camera_name,
            priority_order=priority_order,
        )

class MobilityParameters(Struct):
    velocity_max: List[float]
    leg_length: float
    step_clearance: float
    avoid_obstacles: bool
    obstacle_threshold: float
    feet_avoid_unsteppable_regions: bool
    feet_match_terrain: bool
    def __init__(
            self,
            velocity_max: List[float] = None,
            leg_length: float = None,
            step_clearance: float = None,
            avoid_obstacles: bool = None,
            obstacle_threshold: float = None,
            feet_avoid_unsteppable_regions: bool = None,
            feet_match_terrain: bool = None,
            locomotion_type: str = None,
            stance_width: float = None,
    ):
        super().__init__(
            velocity_max=velocity_max,
            leg_length=leg_length,
            step_clearance=step_clearance,
            avoid_obstacles=avoid_obstacles,
            obstacle_threshold=obstacle_threshold,
            feet_avoid_unsteppable_regions=feet_avoid_unsteppable_regions,
            feet_match_terrain=feet_match_terrain,
        )

class TagMeasurement(Struct):
    id: int
    update_time: float
    base_to_tag_pose: Pose
    corners: Optional[List[float]]
    def __init__(
            self,
            id: int = None,
            update_time: float = None,
            base_to_tag_pose: Pose = None,
            corners: Optional[List[float]] = None,
    ):
        super().__init__(
            id=id,
            update_time=update_time,
            base_to_tag_pose=base_to_tag_pose,
            corners=corners,
        )

class ObjectAttributes(Struct):
    name: Optional[str]
    parent: Optional[int]
    children: Optional[List[int]]
    timeout: Optional[float]
    mass: Optional[float]
    box_geometry: Optional[List[float]]
    box_seen_time: Optional[float]
    polygon: Optional[List[List[float]]]
    tag_measurement: Optional['TagMeasurement']
    april_tag_id: Optional[int]
    keep_out: bool
    steppable: bool
    pickable: bool
    transient: bool
    keep_orphaned: bool
    def __init__(
            self,
            name: Optional[str] = None,
            parent: Optional[int] = None,
            children: Optional[List[int]] = None,
            timeout: Optional[float] = None,
            mass: Optional[float] = None,
            box_geometry: Optional[List[float]] = None,
            box_seen_time: Optional[float] = None,
            polygon: Optional[List[List[float]]] = None,
            tag_measurement: Optional['TagMeasurement'] = None,
            april_tag_id: Optional[int] = None,
            keep_out: bool = None,
            steppable: bool = None,
            pickable: bool = None,
            transient: bool = None,
            keep_orphaned: bool = None,
    ):
        super().__init__(
            name=name,
            parent=parent,
            children=children,
            timeout=timeout,
            mass=mass,
            box_geometry=box_geometry,
            box_seen_time=box_seen_time,
            polygon=polygon,
            tag_measurement=tag_measurement,
            april_tag_id=april_tag_id,
            keep_out=keep_out,
            steppable=steppable,
            pickable=pickable,
            transient=transient,
            keep_orphaned=keep_orphaned,
        )

class Landmark(Struct):
    id: int
    pose: Pose
    std_dev: SpatialVector
    def __init__(
            self,
            id: int = None,
            pose: Pose = None,
            std_dev: SpatialVector = None,
    ):
        super().__init__(
            id=id,
            pose=pose,
            std_dev=std_dev,
        )



# Message definitions

class ActionSetOperationMode(Message):
    mode: str
    def __init__(
            self,
            mode: str = None,
    ):
        super().__init__(
            'action-set-operation-mode',
            mode=mode,
        )

class ActionIdle(Message):
    def __init__(
            self,
    ):
        super().__init__(
            'action-idle',
        )

class ActionStart(Message):
    mode: str
    def __init__(
            self,
            mode: str = None,
    ):
        super().__init__(
            'action-start',
            mode=mode,
        )

class ActionSit(Message):
    def __init__(
            self,
    ):
        super().__init__(
            'action-sit',
        )

class ActionShutdown(Message):
    def __init__(
            self,
    ):
        super().__init__(
            'action-shutdown',
        )

class ActionCalibrateImu(Message):
    def __init__(
            self,
    ):
        super().__init__(
            'action-calibrate-imu',
        )

class ActionGoto(Message):
    target: GpsPose
    reference_frame: 'ObjectSelector'
    position_tolerance: float
    orientation_tolerance: float
    mobility_parameters: 'MobilityParameters'
    def __init__(
            self,
            target: GpsPose = None,
            reference_frame: 'ObjectSelector' = None,
            position_tolerance: float = None,
            orientation_tolerance: float = None,
            mobility_parameters: 'MobilityParameters' = None,
            speed: Optional[float] = None,
            avoid_obstacles: Optional[bool] = None,
            obstacle_threshold: Optional[float] = None,
    ):
        super().__init__(
            'action-goto',
            target=target,
            reference_frame=reference_frame,
            position_tolerance=position_tolerance,
            orientation_tolerance=orientation_tolerance,
            mobility_parameters=mobility_parameters,
        )

class ActionMove(Message):
    velocity: SpatialVector
    mobility_parameters: 'MobilityParameters'
    def __init__(
            self,
            velocity: SpatialVector = None,
            mobility_parameters: 'MobilityParameters' = None,
            avoid_obstacles: Optional[bool] = None,
            obstacle_threshold: Optional[float] = None,
    ):
        super().__init__(
            'action-move',
            velocity=velocity,
            mobility_parameters=mobility_parameters,
        )

class ActionPick(Message):
    object: 'ObjectSelector'
    mobility_parameters: 'MobilityParameters'
    def __init__(
            self,
            object: 'ObjectSelector' = None,
            mobility_parameters: 'MobilityParameters' = None,
    ):
        super().__init__(
            'action-pick',
            object=object,
            mobility_parameters=mobility_parameters,
        )

class ActionPlace(Message):
    pose: Pose
    reference_frame: 'ObjectSelector'
    position_tolerance: float
    mobility_parameters: 'MobilityParameters'
    def __init__(
            self,
            pose: Pose = None,
            reference_frame: 'ObjectSelector' = None,
            position_tolerance: float = None,
            mobility_parameters: 'MobilityParameters' = None,
    ):
        super().__init__(
            'action-place',
            pose=pose,
            reference_frame=reference_frame,
            position_tolerance=position_tolerance,
            mobility_parameters=mobility_parameters,
        )

class ActionStand(Message):
    base_pose: Pose
    duration: float
    mobility_parameters: 'MobilityParameters'
    def __init__(
            self,
            base_pose: Pose = None,
            duration: float = None,
            mobility_parameters: 'MobilityParameters' = None,
    ):
        super().__init__(
            'action-stand',
            base_pose=base_pose,
            duration=duration,
            mobility_parameters=mobility_parameters,
        )

class ActionEndEffectorMove(Message):
    end_effector: str
    waypoints: List[Pose]
    reference_frame: 'ObjectSelector'
    stall_threshold: Optional[float]
    cyclic: bool
    max_speed: float
    duration: float
    transition_duration: Optional[float]
    def __init__(
            self,
            end_effector: str = None,
            waypoints: List[Pose] = None,
            reference_frame: 'ObjectSelector' = None,
            stall_threshold: Optional[float] = None,
            cyclic: bool = None,
            max_speed: float = None,
            duration: float = None,
            transition_duration: Optional[float] = None,
            use_time_optimal: bool = None,
            avoid_obstacles: bool = None,
    ):
        super().__init__(
            'action-end-effector-move',
            end_effector=end_effector,
            waypoints=waypoints,
            reference_frame=reference_frame,
            stall_threshold=stall_threshold,
            cyclic=cyclic,
            max_speed=max_speed,
            duration=duration,
            transition_duration=transition_duration,
        )

class ActionSequential(Message):
    actions: List[Message]
    def __init__(
            self,
            actions: List[Message] = None,
    ):
        super().__init__(
            'action-sequential',
            actions=actions,
        )

class ActionConcurrent(Message):
    actions: List[Message]
    def __init__(
            self,
            actions: List[Message] = None,
    ):
        super().__init__(
            'action-concurrent',
            actions=actions,
        )

class ActionTimeout(Message):
    action: Message
    timeout: float
    def __init__(
            self,
            action: Message = None,
            timeout: float = None,
    ):
        super().__init__(
            'action-timeout',
            action=action,
            timeout=timeout,
        )

class ActionDuration(Message):
    action: Message
    duration: float
    after_success: bool
    def __init__(
            self,
            action: Message = None,
            duration: float = None,
            after_success: bool = None,
    ):
        super().__init__(
            'action-duration',
            action=action,
            duration=duration,
            after_success=after_success,
        )

class ActionLoop(Message):
    action: Message
    count: Optional[int]
    def __init__(
            self,
            action: Message = None,
            count: Optional[int] = None,
    ):
        super().__init__(
            'action-loop',
            action=action,
            count=count,
        )

class RequestPrivilege(Message):
    privilege: str
    priority: int
    def __init__(
            self,
            privilege: str = None,
            priority: int = None,
    ):
        super().__init__(
            'request-privilege',
            privilege=privilege,
            priority=priority,
        )

class DropPrivilege(Message):
    privilege: str
    def __init__(
            self,
            privilege: str = None,
    ):
        super().__init__(
            'drop-privilege',
            privilege=privilege,
        )

class GetPrivileges(Message):
    def __init__(
            self,
    ):
        super().__init__(
            'get-privileges',
        )

class StartPersistentSession(Message):
    name: str
    timeout: float
    def __init__(
            self,
            name: str = None,
            timeout: float = None,
    ):
        super().__init__(
            'start-persistent-session',
            name=name,
            timeout=timeout,
        )

class ResumePersistentSession(Message):
    name: Optional[str]
    token: Optional[str]
    def __init__(
            self,
            name: Optional[str] = None,
            token: Optional[str] = None,
    ):
        super().__init__(
            'resume-persistent-session',
            name=name,
            token=token,
        )

class StopPersistentSession(Message):
    name: Optional[str]
    token: Optional[str]
    def __init__(
            self,
            name: Optional[str] = None,
            token: Optional[str] = None,
    ):
        super().__init__(
            'stop-persistent-session',
            name=name,
            token=token,
        )

class DefaultMobilityParameters(Message):
    mobility_parameters: 'MobilityParameters'
    def __init__(
            self,
            mobility_parameters: 'MobilityParameters' = None,
    ):
        super().__init__(
            'default-mobility-parameters',
            mobility_parameters=mobility_parameters,
        )

class GetConfigInfo(Message):
    def __init__(
            self,
    ):
        super().__init__(
            'get-config-info',
        )

class AddSequentialActions(Message):
    actions: List[Message]
    reference_number: Optional[int]
    append: bool
    def __init__(
            self,
            actions: List[Message] = None,
            reference_number: Optional[int] = None,
            append: bool = None,
    ):
        super().__init__(
            'add-sequential-actions',
            actions=actions,
            reference_number=reference_number,
            append=append,
        )

class AddConcurrentActions(Message):
    actions: List[Message]
    reference_number: Optional[int]
    def __init__(
            self,
            actions: List[Message] = None,
            reference_number: Optional[int] = None,
    ):
        super().__init__(
            'add-concurrent-actions',
            actions=actions,
            reference_number=reference_number,
        )

class ReplaceAction(Message):
    action: Message
    reference_number: Optional[int]
    fallback: str
    def __init__(
            self,
            action: Message = None,
            reference_number: Optional[int] = None,
            fallback: str = None,
    ):
        super().__init__(
            'replace-action',
            action=action,
            reference_number=reference_number,
            fallback=fallback,
        )

class RemoveAction(Message):
    reference_number: Optional[int]
    def __init__(
            self,
            reference_number: Optional[int] = None,
    ):
        super().__init__(
            'remove-action',
            reference_number=reference_number,
        )

class GetActionCommand(Message):
    def __init__(
            self,
    ):
        super().__init__(
            'get-action-command',
        )

class GetExecutionState(Message):
    def __init__(
            self,
    ):
        super().__init__(
            'get-execution-state',
        )

class SimulatorEmergencyStop(Message):
    enable_motors: bool
    def __init__(
            self,
            enable_motors: bool = None,
    ):
        super().__init__(
            'simulator-emergency-stop',
            enable_motors=enable_motors,
        )

class SimulatorApplyForce(Message):
    model_id: int
    body: Optional[str]
    offset: List[float]
    reference: str
    force: SpatialVector
    duration: float
    def __init__(
            self,
            model_id: int = None,
            body: Optional[str] = None,
            offset: List[float] = None,
            reference: str = None,
            force: SpatialVector = None,
            duration: float = None,
    ):
        super().__init__(
            'simulator-apply-force',
            model_id=model_id,
            body=body,
            offset=offset,
            reference=reference,
            force=force,
            duration=duration,
        )

class SimulatorSetPose(Message):
    model_id: int
    pose: Pose
    velocity: Optional[SpatialVector]
    def __init__(
            self,
            model_id: int = None,
            pose: Pose = None,
            velocity: Optional[SpatialVector] = None,
    ):
        super().__init__(
            'simulator-set-pose',
            model_id=model_id,
            pose=pose,
            velocity=velocity,
        )

class SimulatorLoadToml(Message):
    toml: str
    def __init__(
            self,
            toml: str = None,
    ):
        super().__init__(
            'simulator-load-toml',
            toml=toml,
        )

class SimulatorPause(Message):
    def __init__(
            self,
    ):
        super().__init__(
            'simulator-pause',
        )

class SimulatorStart(Message):
    def __init__(
            self,
    ):
        super().__init__(
            'simulator-start',
        )

class CancelQuery(Message):
    reference_number: Optional[int]
    def __init__(
            self,
            reference_number: Optional[int] = None,
    ):
        super().__init__(
            'cancel-query',
            reference_number=reference_number,
        )

class SetFloorplanMap(Message):
    name: str
    image_data: str
    resolution: float
    origin: Pose
    landmarks: List['Landmark']
    initial_pose: Pose
    def __init__(
            self,
            name: str = None,
            image_data: str = None,
            resolution: float = None,
            origin: Pose = None,
            landmarks: List['Landmark'] = None,
            initial_pose: Pose = None,
    ):
        super().__init__(
            'set-floorplan-map',
            name=name,
            image_data=image_data,
            resolution=resolution,
            origin=origin,
            landmarks=landmarks,
            initial_pose=initial_pose,
        )

class AddLandmarks(Message):
    map_name: str
    landmarks: List['Landmark']
    def __init__(
            self,
            map_name: str = None,
            landmarks: List['Landmark'] = None,
    ):
        super().__init__(
            'add-landmarks',
            map_name=map_name,
            landmarks=landmarks,
        )

class ClearFloorplanMap(Message):
    name: str
    def __init__(
            self,
            name: str = None,
    ):
        super().__init__(
            'clear-floorplan-map',
            name=name,
        )

class SetFloorplanMapToBasePose(Message):
    name: str
    pose: Pose
    def __init__(
            self,
            name: str = None,
            pose: Pose = None,
    ):
        super().__init__(
            'set-floorplan-map-to-base-pose',
            name=name,
            pose=pose,
        )

class AddObject(Message):
    attributes: 'ObjectAttributes'
    transform: Optional[Pose]
    velocity: Optional[SpatialVector]
    relative_to: 'ObjectSelector'
    in_coordinates_of: 'ObjectSelector'
    stored_relative_to: 'ObjectSelector'
    def __init__(
            self,
            attributes: 'ObjectAttributes' = None,
            transform: Optional[Pose] = None,
            velocity: Optional[SpatialVector] = None,
            relative_to: 'ObjectSelector' = None,
            in_coordinates_of: 'ObjectSelector' = None,
            stored_relative_to: 'ObjectSelector' = None,
    ):
        super().__init__(
            'add-object',
            attributes=attributes,
            transform=transform,
            velocity=velocity,
            relative_to=relative_to,
            in_coordinates_of=in_coordinates_of,
            stored_relative_to=stored_relative_to,
        )

class RemoveObjects(Message):
    objects: 'ObjectSelector'
    def __init__(
            self,
            objects: 'ObjectSelector' = None,
    ):
        super().__init__(
            'remove-objects',
            objects=objects,
        )

class SetObjectAttributes(Message):
    object: 'ObjectSelector'
    attributes: 'ObjectAttributes'
    def __init__(
            self,
            object: 'ObjectSelector' = None,
            attributes: 'ObjectAttributes' = None,
    ):
        super().__init__(
            'set-object-attributes',
            object=object,
            attributes=attributes,
        )

class RemoveObjectAttributes(Message):
    object: 'ObjectSelector'
    attributes: List[str]
    def __init__(
            self,
            object: 'ObjectSelector' = None,
            attributes: List[str] = None,
    ):
        super().__init__(
            'remove-object-attributes',
            object=object,
            attributes=attributes,
        )

class SetObjectKinematics(Message):
    object: 'ObjectSelector'
    transform: Pose
    velocity: Optional[SpatialVector]
    relative_to: 'ObjectSelector'
    in_coordinates_of: 'ObjectSelector'
    stored_relative_to: 'ObjectSelector'
    def __init__(
            self,
            object: 'ObjectSelector' = None,
            transform: Pose = None,
            velocity: Optional[SpatialVector] = None,
            relative_to: 'ObjectSelector' = None,
            in_coordinates_of: 'ObjectSelector' = None,
            stored_relative_to: 'ObjectSelector' = None,
    ):
        super().__init__(
            'set-object-kinematics',
            object=object,
            transform=transform,
            velocity=velocity,
            relative_to=relative_to,
            in_coordinates_of=in_coordinates_of,
            stored_relative_to=stored_relative_to,
        )

class QueryGroup(Message):
    queries: List[Message]
    period: Optional[float]
    def __init__(
            self,
            queries: List[Message] = None,
            period: Optional[float] = None,
    ):
        super().__init__(
            'query-group',
            queries=queries,
            period=period,
        )

class GetTimestamp(Message):
    def __init__(
            self,
    ):
        super().__init__(
            'get-timestamp',
        )

class GetObjectKinematics(Message):
    object: 'ObjectSelector'
    relative_to: 'ObjectSelector'
    in_coordinates_of: 'ObjectSelector'
    def __init__(
            self,
            object: 'ObjectSelector' = None,
            relative_to: 'ObjectSelector' = None,
            in_coordinates_of: 'ObjectSelector' = None,
    ):
        super().__init__(
            'get-object-kinematics',
            object=object,
            relative_to=relative_to,
            in_coordinates_of=in_coordinates_of,
        )

class GetBatteryStatus(Message):
    def __init__(
            self,
    ):
        super().__init__(
            'get-battery-status',
        )

class GetRobotInfo(Message):
    def __init__(
            self,
    ):
        super().__init__(
            'get-robot-info',
        )

class GetRobotStatus(Message):
    def __init__(
            self,
    ):
        super().__init__(
            'get-robot-status',
        )

class GetLandmarks(Message):
    map_name: str
    def __init__(
            self,
            map_name: str = None,
    ):
        super().__init__(
            'get-landmarks',
            map_name=map_name,
        )

class GetSnapshot(Message):
    camera: str
    quality: int
    def __init__(
            self,
            camera: str = None,
            quality: int = None,
    ):
        super().__init__(
            'get-snapshot',
            camera=camera,
            quality=quality,
        )

class GetObject(Message):
    object: 'ObjectSelector'
    def __init__(
            self,
            object: 'ObjectSelector' = None,
    ):
        super().__init__(
            'get-object',
            object=object,
        )

class NotifyObjects(Message):
    objects: 'ObjectSelector'
    persistent: bool
    def __init__(
            self,
            objects: 'ObjectSelector' = None,
            persistent: bool = None,
    ):
        super().__init__(
            'notify-objects',
            objects=objects,
            persistent=persistent,
        )

class GetGpsCoordinates(Message):
    object: 'ObjectSelector'
    def __init__(
            self,
            object: 'ObjectSelector' = None,
    ):
        super().__init__(
            'get-gps-coordinates',
            object=object,
        )

